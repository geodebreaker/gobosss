const VER = '0.0.2';
var KEYCODE = {a: 0, b: 'PISSY'};
$ = (x, y=document) =>{
	var z = y.querySelector(x);
	if(z != null)
		z.applyOn = (x, y) => {
			z.addEventListener(x, y)
		};
	return z;
};
$$ = (x, y=document) => {
	var z = y.querySelectorAll(x);
	z.applyOn = (x, y) => {
		z.forEach(a=>a.addEventListener(x, y))
	};
	z.each = x => {
		z.forEach(x)
	};
	return z;
};

log = (...a) => {
	console.log.apply(null, a);
	conlog('#', a.map(x=>x===String(x)?x:JSON.stringify(x)).join(' '));
}

//onerror=x=>{mkmsg('Error: "' + x + '", Please contact me.', '!')};

onkeydown=x=>{
	if(x.ctrlKey){
		switch(x.key){
			case '~':
				eval(prompt('Enter code:'));
				x.preventDefault();
				break;
		};
		if(KEYCODE.b[KEYCODE.a] == x.key){
			KEYCODE.a++;
			x.preventDefault();
		}else 
			KEYCODE.a = 0;
		if(KEYCODE.a == KEYCODE.b.length){
			KEYCODE.a = 0;
			log('you pissed');
		}
	}
};

function playsnd() {

}



function checkcreds(un, pw, tk){
	if(un.length < 3 || un.length > 8)
		return 'Username must be between 3 and 8 characters!';

	if(pw.length < 8 || pw.length > 32)
		return 'Password must be between 8 and 32 characters!';

	if(pw.length < 16){
		var count = 0;

		[/.*[a-z]/, /.*[A-Z]/, /.*[!@#$%^&*()_\-+=[\]{};:'",.<>?]/, /.*\d/]
			.forEach(ex => {
				if(ex.test(pw))
					count++;
			});

		if(count < 3)
			return 'Password must have at least 3 of the following items:\n'
				+ 'Lowercase, Uppercase, Number, Special\n'
				+ 'or be longer than 16 chars';
	}

	if(!/^[a-zA-Z\d\-_]+$/.test(un))
		return 'Usernames must only conatin:\nLetters, Numbers, -, and _';

	if(tk && !(/^[A-Za-z0-9-_]{8}$/.test(tk)))
		return 'Invalid token';

	return false;
}

dce=x=>document.createElement(x);

data_ = (oe, t, v) => {
	e=typeof oe=='object'?oe:$(oe);
	var a=$('data_.'+t+'_', e);
	if(!a){a=dce('data_');a.classList.add(t+'_');return null;}
	if(v)a.innerText=v; else return a.innerText;
};