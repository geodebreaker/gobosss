var udat = {un: null, uid: null, o: null}

var users = {
	'ADMIN': {
		name: 'admin',
		bio: 'placeholder',
		rank: 2, //0:user,1:bot,2:dev
		karma: 0,
		follow: true,
		followers: 0,
	},
	'GEODE-USER-ID': {
		name: 'geode',
		bio: 'shißenheimer 🅱',
		rank: 2,
		karma: Infinity,
		follow: true,
		followers: 9,
	}
};

var posts = {
	0: {
		uservote: 1,
		vote: 3,
		from: 'ADMIN',
		time: 0,
		post: 'Feed',
		parent: 0, 
		children: ['OMG-MH-REAL'],
		_HTMLREF: null,
	},
	'OMG-MH-REAL': {
		uservote: 1,
		vote: 2,
		from: 'GEODE-USER-ID',
		time: 0,
		post: 'omg mh real?\n'.repeat(10),
		parent: 0, 
		children: [],
		_HTMLREF: null,
	}
};

posthtml = 
				`<div class="p-wrap">
					<data_ class="id_"></data_>
					
					<div class="post con">
						<div class="p-top">
							<span class="pt-username"></span>
							<span class="pt-token">
								<span class="ptt"></span>
								<span class="ptt"></span>
							</span>
							<button class="pt-menu" act="pmenu">:</button>
						</div>
						<div class="p-vote">
							<button 
								class="pv-up" 
								act="upv"
								voted
							>^</button>
							<span class="pv-val">2</span>
							<button 
								class="pv-down" 
								act="downv"
								voted
							>V</button>
							<button class="pv-reply" act="togrep">!</button>
						</div>
						<div class="p-sect">
							<div class="ps-wrap">
								<span class="ps-text">
								</span>
							</div>
						</div>
					</div>
					
					<div class="p-reply pr-hide">
						<div class="pr-write">
							<button class="prw-new" act="rep">+</button>
							<span>Write a Reply</span>
						</div>
						<div class="pr-posts"></div>
					</div>
				</div>
				
			</div>`;