async function net(type, val){
	return new Promise((ye, no) => {
		//use that later

		/*fetch(
			'api/' + type, 
			val?
				{method:'POST',body:JSON.stringify(val),credentials:'include'} :
				{credentials:'include'}
		).catch(e=>{
				no('Net Request Failed: ' + e)
		}).then(async e=>{
			if(!e.ok)
				no('Net Request Failed: ' + e.status)
			var contype = e.headers.get('Content-Type');
			if(contype == 'text/html')
				ye(await x.text());
			if(contype == 'application/json')
				ye(await x.json());
		});*/

		log('req: (ye() or no())\n', type, val);
		window.ye = ye;
		window.no = no;
	})
};