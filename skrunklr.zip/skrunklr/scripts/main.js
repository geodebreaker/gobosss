//VARIABLES


//FUNCTIONS

async function vote(id, t, x){
	netres = await net('vote', {id, val:t.attributes.voted.value != "true" ? x*2-1 : 0});
	if(netres.res != true)
		return;
	$('.pv-' + ['up', 'down'][x], t.parentElement).attributes.voted.value = "false";
	t.attributes.voted.value = t.attributes.voted.value != "true";
	var val = t.attributes.voted.value == "true" ? x*2-1 : 0;
	log('vote',id,val);
	posts[id].uservote = val;
	var p = null;
	$$('data_.id_').each(x=>{if(x.innerText==id)p=x.parentElement});
	if(p!=null){
		$('.pv-val', p).innerText = posts[id].vote + posts[id].uservote;
	}
}

function ACT(t, a){
	log('action:', a);
	var id = data_(t.parentElement.parentElement.parentElement, 'id');
	switch(a){
		case 'togrep':
			$('.p-reply', t.parentElement.parentElement.parentElement)
				.classList.toggle('pr-hide');
			break;
		case 'rep':
			writepost(id);
			break;
		case 'upv':
		case 'downv':
			var x = a == 'downv' ? 0 : 1;
			vote(id, t, x);
			break;
	}
}

function writepost(id){
	var elm = $('#write');
	data_(elm, 'id', id);
	$('#w-type', elm).innerText = posts[id].post.split('\n')[0];
	elm.showPopover();
}

function err(e){
	conlog('<span class="red">!', e, '</span>');
	var elm = $('#error');
	$('.code', elm).innerText = e;
	$('.box', elm).innerHTML = $('#c-log').innerHTML.split('<br>').slice(-5).join('<br>');
	elm.showPopover();
}

onerror=err;

function conlog(t, l, u){
	var p = dce('p');
	p.innerText = l;
	$('#c-log').innerHTML += t + '&gt; ' + 
		p.innerHTML.replace(/<br>/g, (u??'')+'<br>'+t+'&gt; ') 
		+ (u ?? '') + '<br>';
	$('#c-log').scrollTop = $('#c-log').scrollHeight;
}

async function loginDone(){
	$('#login').hidePopover();
	$('#undisplay').innerText = '@' + udat.un;
	try{
		var netres = await net('get', {type:'user'});
		if(netres.res == true)
			users[udat.uid] = new User(netres.ud);
	}catch(e){
		err('Could not get user data');
	}
}

async function signin(act, oun, pw, tk){
	var un = oun.toLowerCase();

	var credcheck = checkcreds(un, pw, tk);
	if(credcheck)
		return credcheck;

	var netres = await net('sign' + act, {un, pw, tk});
	if(netres.res != true)
		return 'Sign '+ act +' failed: ' + netres.result;

	if(window.localStorage){
		localStorage.uid = udat.uid;
		localStorage.un  = udat.un;
	}

	loginDone();
}

async function trysign(oact){
	var act = oact ? 'up' : 'in';

	$('#signlog').innerText = 'Signing '+act+'...\n';
	var res = await signin(act, $('#un').value, $('#pw').value, $('#tk').value);

	if(res){
		$('#signlog').innerHTML += `<span class="red">${
			res.replace(/\n/,'<br>')
		}</span>`;
	}else{
		$('#signlog').innerText = '';
	}
}

function newElm(elm){
	if(elm.attributes.onenter!=undefined){
		elm.onkeypress = event =>{
			if(event.key == 'Enter')
				(new Function(elm.attributes.onenter.value).bind(elm))();
		}
	}

	if(elm.attributes.act!=undefined){
		elm.onclick = event =>{
			ACT(elm, elm.attributes.act.value);
		}
	}
}

//SETUP

$('body').applyOn('click', event => {
	if(event.target.tagName == 'BUTTON' && $(':popover-open') != null)
		event.stopPropagation()
});

$$('.m-close').applyOn('click', event => 
	event.target.parentElement.parentElement.hidePopover());

$$('.modal').applyOn('toggle', event => { //empty all inputs when modal closed
	if(event.newState == 'closed')
		$$('input, textarea', event.target).each(input => 
			input.value = '');
});

$('#sibtn').applyOn('click', event =>  //sign in button
	trysign(false));

$('#subtn').applyOn('click', event =>  //sign up button
	trysign(true));

$('#sobtn').applyOn('click', event => { //sign out button
	if($(':popover-open') == null){
		$('#login').showPopover();
		delete localStorage.un;
		delete localStorage.uid;
	}
});

$$('[onenter], [act]').each(newElm);

$('#w-post').applyOn('click', async event => {
	var x = await net('mkpost', {data: $('#w-text').value});
	if(x.res == true){
		posts[x.id] = new Post(x.post);
		$('#write').hidePopover();
	}
})

//READY

async function ready(){
	var check = await net('check'); //check if valid

	if(window.localStorage && localStorage.un && check.res == true){
		udat.un = localStorage.un;
		udat.uid = localStorage.uid;
		loginDone();
	}else{ //creds dont exist
		$('#login').showPopover();
		if(window.localStorage){
			delete localStorage.un;
			delete localStorage.uid;
		}
	}
}

ready();

//TEST
udat.un  = 'geode';
udat.uid = 'GEODE-USER-ID';
// loginDone();