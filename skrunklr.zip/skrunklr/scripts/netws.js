//fake it for now

function send(type, val){
	console.log('send:', {type, val});
}

function msg(type, val){
	switch(type){
		case 'res':
			onres(val.id, val);
			break;
	}
}

/*var ws = new WebSocket((window.location.protocol=='https:'?'wss://':'ws://')+window.location.host);

function send(type, val){
	//if(ws.OPEN){
	var x = JSON.stringify({type, val})
	ws.send(x);
	//}
}*/

var RES = [];
function sres(id, cb){
	RES.push({id,cb});
}
function onres(id, res){
	for(var i = 0; i < RES.length; i++){
		var cb = RES[i];
		if(cb.id == id){
			cb.cb(res);
			RES.splice(i--, 1);
		}
	}
}

/*ws.onclose = function(x){
	if(ping)
		clearInterval(ping);
}

ws.onmessage = function(x){
	y = JSON.parse(x.data);
	console.log('recive:', y)
	msg(y.type, y.val);
}

ws.onopen = () => {
	setLoad();
	ping = setInterval(send, 10000, 'ping');
}*/