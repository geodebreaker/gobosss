var WebSocket = require('ws');
const mysql = require('mysql2');
const port = process.env.PORT || 8080;
const http = require('http');

let fileContent = '';

const httpserver = http.createServer((req, res) => {
		// Allow requests from any origin
		res.setHeader('Access-Control-Allow-Origin', '*');
		// Allow GET, POST, and OPTIONS methods
		res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
		// Set other headers for preflight requests
		res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

		// Handle preflight requests
		if (req.method === 'OPTIONS') {
			res.writeHead(200);
			res.end();
			return;
		}
    if (req.method === 'GET' && req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(fileContent);
    } else if (req.method === 'POST' && req.url === '/save') {
        let body = '';
        req.on('data', (chunk) => {
            body += chunk.toString(); // Convert Buffer to string
        });

        req.on('end', () => {
            try {
                fileContent = body;
  							query(`INSERT INTO code (data) VALUES ('${sqlescape(fileContent)}')`)
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true }));
            } catch (error) {
                console.error(error);
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Failed to save file' }));
            }
        });//Set-Cookie: sessionId=abc123; HttpOnly; Secure; SameSite=strict
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not Found');
    }
});

async function getusers(){
	var tmp = await query('SELECT * FROM users');
	tmp.forEach(user => {
		users[user.un] = user.pw;
	})
}
setInterval(getusers, 60000);

var wss = new WebSocket.Server({ server: httpserver });

var clients = {};
var users = {"a":"b"};

sqlescape=x=>x.replace(/\\/g,"\\\\").replace(/'/g,"\\'");

const conn = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: 'app'
});

query = async (q) => {
	return new Promise((a, b) => {
		conn.query(q, (error, results, fields) => {
		  if (error) {
		    console.error('Error executing query "'+q+'":', error.stack);
		    b(error.stack);
		  }else{
			  console.log('Query "'+q+'" results:', JSON.stringify(results));
				a(results);
			}
		});
	});
}

conn.connect(error => {
  if (error) {
    console.error('Error connecting to the database:', error);
  }else{
  	console.log('Connected to the database');
	}
});

query('SELECT * FROM code WHERE time = (SELECT MAX(time) FROM code)').then(c=>fileContent=c[0].data);

function send(ws, type, value){
	var tmp = structuredClone(value);
	tmp.type = type;
	var parsedmsg = JSON.stringify(tmp);
	console.log(`Sent message to client ${ws.un}: ${parsedmsg}`);
	ws.send(parsedmsg);
}

function emit(type, value, exept){
	var tmp = structuredClone(value);
	tmp.type = type;
	var parsedmsg = JSON.stringify(tmp);
	console.log(`Emited message: ${parsedmsg}`);
	wss.clients.forEach(client=>{
		if(exept){
			if(!exept.contains(client))
				client.send(parsedmsg);
		}else
			client.send(parsedmsg);
	});
}

function useract(act, data){
	switch(act){
		case 'del':
			if(users[data.un]){
				query(`DELETE FROM users WHERE un='${sqlescape(data.un)}'`);
				delete users[data.un];
				return 0;
			}else{
				return 1;
			}
			break;
		case 'add':
			if(!users[data.un]){
				query(`INSERT INTO users (un, pw) VALUES ('
							${sqlescape(data.un)
				}','${
					sqlescape(data.pw)
				}')`);
				return 0;
			}else{
				return 1;
			}
	}
}
/*
		both: response
		    : handshake
		    : msg
		cli : fetch
		    : conn
		    : ping
		    : act
		svr : cred
		    : err
*/
var RES = [];
function sres(id, cb, ws){
	RES.push({id,cb,ws});
}
function onres(id, res, ws){
	for(var i = 0; i < RES.length; i++){
		var cb = RES[i];
		if(cb.id == id  && cb.ws == ws){
			cb.cb(res, ws);
			RES.splice(i--, 1);
		}
	}
}

function message(ws, y){
	switch(y.type){
		case 'res':
			onres(y.id, y.value);
			break;
		case 'msg':
			emit('msg', {value:y.value,from:ws.un}/*, [ws]*/);
			break;
		case 'act':
			var x = y.act.split(':');
			if(x[0] != 'f'){
				useract(x[1], y.value)
			}
			break;
		case 'conn':
			break;
		case 'hand':
			break;
		default:
			send(clients[un], 'err');
			break;
	}
}


wss.on('connection', function connection(ws) {
	var un = null;
	ws.un = null;
	ws.ping = Date.now();
	
	console.log(`Client connected`);

	ws.on('message', function incoming(msg) {
		console.log(`Received from client ${ws.un}: ${msg}`);
	
		var objmsg = JSON.parse(msg);

		if(objmsg.type == 'DG'){ //Debug Get
			//NOTE TO SELF: Do NOT leave in prod i swear
			if(objmsg.value == 'UI') // User Info
				send(ws, 'DG', users);
			return;
		}
		
		if(objmsg.type == 'conn'){
			var conn = objmsg.value;
			if(users[conn.un] != conn.pw){
				send(ws, 'error', 4);
				ws.terminate(1000, 1);
				return 0;
			}

			ws.un = conn.un;
			
			clients[ws.un] = ws;
			
			console.log(`Client ${ws.un} joined`);
			
			emit('join', {value:ws.un})
			return;
		}

		if(objmsg.type == 'reset'){
			console.log('Restarting...');
			wss.clients.forEach(c=>{
				send(c,'error','-2');
				c.terminate(1000, 1);
				console.log(`Ended a connection to ${c.un}`);
			});
			clients = [];
			console.log('Cleared clients list');
			return;
		}
		
		if(objmsg.type == 'ping'){
			ws.ping = Date.now();
		}
		
		if(un != null){
			message(ws, objmsg);
		}
  });

  ws.on('close', function close() {
		console.log(`Client ${ws.un} disconnected`);
		emit('leave', {value:ws.un});
		delete clients[ws.un];
  });
});

httpserver.listen(8080, () => {
    console.log('Server is listening on port 8080');
});


