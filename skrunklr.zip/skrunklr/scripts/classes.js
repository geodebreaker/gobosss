class Post{
	constructor(data){
		this.id = data.id;
		this.uservote = data.u;
		this.vote = data.v;
		this.from = data.f;
		if(!users[this.f])
			users[this.f] = new User(data.fd);
		this.time = data.t;
		this.post = data.d;
		this.parent = data.p;
		this.children = data.c;
		this.seen = data.s;
		
		posts[this.id] = this;
		this.update = Date.now();
	}

	createHTML(){
		if(this._HTMLREF)
			return this._HTMLREF;
			
		var x = dce('p');
		x.innerHTML = posthtml;

		$('data_.id_', x).innerText = this.id;
		$('.pt-username', x).innerText = '@' + users[this.id].name;
		$('.pv-up', x).attributes.voted.value = this.uservote == 1;
		$('.pv-down', x).attributes.voted.value = this.uservote == -1;
		$('.ps-text', x).innerText = this.p;

		this._HTMLREF = x.firstElementChild;
		return this._HTMLREF;
	}

	async openRep(){
		for(var x of $('.pr-posts', this._HTMLREF).children){
			
		}
		var x = await net('getposts', this.children.filter(x=>{
			if(posts[x])
				posts[x].checkUpdate();
			return !posts[x];
		}));
		
		if(x.res != 'true')
			return;
		x.posts.forEach(p=>{
			posts[p.id]=new Post(p);
			posts[p.id].createHTML();
		});
		this.children.forEach(id=>{
			var p = posts[id];
			$('.pr-posts', this._HTMLREF).appendChild
		})
	}

	async checkUpdate(){
		var t = Date.now();
		if(t-this.update > 60e3){
			this.update = t;
			var nr = await net('getpost', this.id);
			var x = new Post(nr.post);
			for(var y in x){
				this[y] = x[y];
			}
		}
	}

	view(){
		if(!this.seen){
			net('view', this.id);
			this.seen = true;	
		}
		this.checkUpdate();
	}
}

class User{
	constructor(data){
		this.id = data.id;
		this.name = data.n;
		this.bio = data.b;
		this.rank = data.r;
		this.karma = data.k;
		this.follow = data.f;
		
		users[this.id] = this;
	}
}