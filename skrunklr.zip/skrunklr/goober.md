# idk
this is a goober

---

## 


## 


## 


---

## ideas
- 
- 
- 

## todo
- 
- 
- 

## doin
- 
- 
- 